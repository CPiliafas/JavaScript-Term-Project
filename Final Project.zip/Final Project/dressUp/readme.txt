The purpose of this game is to provide a simple dress up game for younger players or people simply
wanting a nice and easy game to play. There weren't many issues getting this game to work. If I
had to improve anything, I would see if I can get the clothing pieces to load up in certain positions
so that it's easier to click and drag a specific item. All the pixel graphics were created by me.