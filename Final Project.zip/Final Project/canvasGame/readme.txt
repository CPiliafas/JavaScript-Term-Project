To play this game, simply use the arrow keys to move the superhero in any direction and avoid the
skyscrapers. Problems with this game that managed to get resolved was getting the music to work. It
seems to work when the game isn't being loaded off an e: drive and instead is live and being played off
a server. If I could fix anything, I'd try and include some more obstacles to make the game a bit 
more difficult. All images and music found are owned by stock/royalty free sites. 