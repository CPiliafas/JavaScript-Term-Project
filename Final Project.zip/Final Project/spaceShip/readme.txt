To play this game, press the buttons to move the spaceship in any direction you would like.
You can also shake and stop the rocket at any point. There is one current issue where the rocket
will stop moving and won't go past a certain point when you move it right, while all the other
dimensions work properly. If I could, I would fix this and maybe even include an alien UFO that the
player must avoid. That will be something I would do for a future release of this game.
All images and music found are owned by stock/royalty free sites. 